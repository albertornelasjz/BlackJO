﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BlackJO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJO {

    /// <summary>
    /// Unit tests
    /// </summary>
    [TestClass()]
    public class GameTests {

		#region POSSITIVE TESTS
		/// <summary>
		/// Cruppier wins perfectly but user exceedes
		/// </summary>
		[TestMethod()]
		public void CruppierWinsPerfectlyAndPlayerExceedes() {
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 10, 10, 10));
			AssignTestCards(game.crupier, 10, 10, 1);
			Assert.AreEqual("Crupier", game.ConcludeGame()[0].Name);
		}

		/// <summary>
		/// Cruppier wins perfectly but user score is short
		/// </summary>
		[TestMethod()]
		public void CruppierWinsPerfectlyAndPlayerIsShort() {
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 1, 5, 10));
			AssignTestCards(game.crupier, 10, 10, 1);
			Assert.AreEqual("Crupier", game.ConcludeGame()[0].Name);
		}

		/// <summary>
		/// Cruppier wins perfectly but user score is in range
		/// </summary>
		[TestMethod()]
		public void CruppierWinsPerfectlyAndPlayerIsInRange() {
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 2, 5, 10));
			AssignTestCards(game.crupier, 10, 10, 1);
			Assert.AreEqual("Crupier", game.ConcludeGame()[0].Name);
		}

		/// <summary>
		/// Player wins perfectly but crupier exceedes
		/// </summary>
		[TestMethod()]
		public void PlayerWinsPerfectlyAndCruppierExceedes() {
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 10, 10, 1));
			AssignTestCards(game.crupier, 10, 10, 10);
			Assert.AreEqual("Player 1", game.ConcludeGame()[0].Name);
		}

		/// <summary>
		/// Player wins perfectly but user score is short
		/// </summary>
		[TestMethod()]
		public void PlayerWinsPerfectlyAndCrupierIsShort() {
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 10, 10, 1));
			AssignTestCards(game.crupier, 5, 5, 6);
			Assert.AreEqual("Player 1", game.ConcludeGame()[0].Name);
		}

		/// <summary>
		/// Player wins perfectly but user score is in range
		/// </summary>
		[TestMethod()]
		public void PlayerWinsPerfectlyAndCrupierIsInRange() {
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 10, 10, 1));
			AssignTestCards(game.crupier, 5, 5, 7);
			Assert.AreEqual("Player 1", game.ConcludeGame()[0].Name);
		}

		/// <summary>
		/// Cruppier wins by proximity
		/// </summary>
		[TestMethod()]
		public void CruppierWinsByProximity() {
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 10, 5, 3));
			AssignTestCards(game.crupier, 10, 1, 9);
			Assert.AreEqual("Crupier", game.ConcludeGame()[0].Name);
		}

		/// <summary>
		/// Player wins by proximity
		/// </summary>
		[TestMethod()]
		public void PlayerWinsByProximity() {
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 10, 8, 2));
			AssignTestCards(game.crupier, 5, 5, 9);
			Assert.AreEqual("Player 1", game.ConcludeGame()[0].Name);
		}	 
		#endregion

		#region DRAW RESULTS TESTS
		/// <summary>
		/// Draw result by perfect score
		/// </summary>
		[TestMethod()]
		public void DrawPerfectResult() {
			List<Player> winners;
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 10, 10, 1));
			AssignTestCards(game.crupier, 10, 10, 1);
			winners = game.ConcludeGame();
			Assert.AreEqual(2, winners.Count());
		}

		/// <summary>
		/// Draw result by perfect score
		/// </summary>
		[TestMethod()]
		public void DrawByLowerLimitResult() {
			List<Player> winners;
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 10, 5, 2));
			AssignTestCards(game.crupier, 10, 5, 2);
			winners = game.ConcludeGame();
			Assert.AreEqual(2, winners.Count());
		}

		/// <summary>
		/// Draw result by perfect score
		/// </summary>
		[TestMethod()]
		public void DrawResult() {
			List<Player> winners;
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 10, 5, 4));
			AssignTestCards(game.crupier, 10, 5, 4);
			winners = game.ConcludeGame();
			Assert.AreEqual(2, winners.Count());
		}	

		#endregion

		#region NEGATIVES TESTS
		/// <summary>
		/// All players have score greater than maxim limit
		/// </summary>
		[TestMethod()]
		public void GreaterThanGoalDrawResult() {
			List<Player> winners;
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 10, 10, 10));
			AssignTestCards(game.crupier, 10, 10, 10);
			winners = game.ConcludeGame();
			Assert.AreEqual(0, winners.Count());
		}

		/// <summary>
		/// All players have score greater than maxim limit with different scores
		/// </summary>
		[TestMethod()]
		public void GreaterThanGoalDifferentScores() {
			List<Player> winners;
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 10, 10, 9));
			AssignTestCards(game.crupier, 10, 10, 10);
			winners = game.ConcludeGame();
			Assert.AreEqual(0, winners.Count());
		}

		/// <summary>
		/// All players have score smaller than low limit
		/// </summary>
		[TestMethod()]
		public void MinorThanLowLimitDrawResult() {
			List<Player> winners;
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 1, 1, 1));
			AssignTestCards(game.crupier, 1, 1, 1);
			winners = game.ConcludeGame();
			Assert.AreEqual(0, winners.Count());
		}

		/// <summary>
		/// All players have score smaller than low limit
		/// </summary>
		[TestMethod()]
		public void MinorThanLowLimitDifferentScores() {
			List<Player> winners;
			Game game = new Game();
			game.players.Add(CreateTestPlayer("Player 1", 1, 2, 13));
			AssignTestCards(game.crupier, 1, 1, 1);
			winners = game.ConcludeGame();
			Assert.AreEqual(0, winners.Count());
		}
		#endregion	

		#region TOOLS
		/// <summary>
		/// Generates a player object to testing purposes
		/// </summary>
		/// <param name="name">Player name</param>
		/// <param name="cards">Card values</param>
		/// <returns>Player object</returns>
		private Player CreateTestPlayer(string name, params int[] cards) {
			Player tempPlayer = new Player(name);
			Game.Card tempCard;
			foreach (int cardValue in cards) {
				tempCard = new Game.Card();
				tempCard.Value = cardValue;
				tempPlayer.Cards.Add(tempCard);
			}
			return tempPlayer;
		}

		/// <summary>
		/// Assigns cards to an existing player
		/// </summary>
		/// <param name="player">Player</param>
		/// <param name="cards">Card values</param>
		private void AssignTestCards(Player player, params int[] cards) {
			Game.Card tempCard;
			player.Cards.Clear();
			foreach (int cardValue in cards) {
				tempCard = new Game.Card();
				tempCard.Value = cardValue;
				player.Cards.Add(tempCard);
			}
		} 
		#endregion

    }

}