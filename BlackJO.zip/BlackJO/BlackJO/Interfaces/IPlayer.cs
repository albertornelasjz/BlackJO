﻿using System.Collections.Generic;

namespace BlackJO {

    /// <summary>
    /// IPlayer interface
    /// </summary>
    interface IPlayer {

        // Player name
        string Name { get; }
        
        // PLayer cards
        List<Game.Card> Cards { get; set; }

        // Show player hand
        void ShowHand();
    }

}
