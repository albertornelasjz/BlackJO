﻿using System;

namespace BlackJO {

    /// <summary>
    /// UI Helper class, helps to give format to console output
    /// </summary>
    internal static class UIHelper {

        /// <summary>
        /// Adds a header
        /// </summary>
        /// <param name="title">Title</param>
        public static void AddHeader(string title) {
            Console.WriteLine(String.Format("==================== {0} ====================", title));
            Console.WriteLine();
        }

        /// <summary>
        /// Adds a label 
        /// </summary>
        /// <param name="label">Label</param>
        public static void AddLabel(string label) {
            Console.WriteLine(label);
            Console.WriteLine();
        }

        /// <summary>
        /// Adds a footer, it closes a section
        /// </summary>
        public static void AddFooter() {
            Console.WriteLine("=======================================================\n");            
        }

    }

}
