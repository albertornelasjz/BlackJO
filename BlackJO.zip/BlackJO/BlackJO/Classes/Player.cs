﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlackJO {

    /// <summary>
    /// Player class, implements IPlayer interface
    /// </summary>
    public class Player : IPlayer {

        // Constants
        internal const string DefaultPlayerName = "Player";

        // Attributes
        private string name;
        private List<Game.Card> cards;

        /// <summary>
        /// Sum of the value of the cards
        /// </summary>
        public int Score {
            get {
                return Cards.Sum(c => c.Value);
            }
        }

        /// <summary>
        /// Player name
        /// </summary>
        public string Name {
            get { return name; }
            set { name = string.IsNullOrEmpty(value) ? DefaultPlayerName : value; }
        }

        /// <summary>
        /// Cards set
        /// </summary>
        public List<Game.Card> Cards {
            get { return cards; }
            set { cards = value == null ? new List<Game.Card>() : value; }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="name">Player name</param>
        public Player(string name) {
            Name = name;
            Cards = new List<Game.Card>();
        }

        /// <summary>
        /// Show hand
        /// </summary>
        public void ShowHand() {
            StringBuilder builder = new StringBuilder().Append("Cards => ");
            UIHelper.AddLabel(String.Format("{0} - Score {1} :", this.Name, this.Score));
            foreach(Game.Card card in this.Cards) {
                builder.Append(String.Format("[{0}] ", card.Value));
            }            
            UIHelper.AddLabel(builder.ToString());
        }
               
    }
        
}
