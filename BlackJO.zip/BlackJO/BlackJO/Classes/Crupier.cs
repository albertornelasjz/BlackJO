﻿namespace BlackJO {

    /// <summary>
    /// Crupier, computer player class. It is a singleton to ensure only one instance of this class
    /// </summary>
    public class Crupier : Player {

        // Attributes
        private static Crupier instance;

        /// <summary>
        /// Gets the unique instance
        /// </summary>
        public static Crupier Instance {
            get {
                if(instance == null) {
                    instance = new Crupier("Crupier");
                }
                return instance;
            }            
        }       

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="name">Player name</param>
        private Crupier(string name) : base (name) { }

        /// <summary>
        /// Completes the rest of the cards
        /// </summary>
        internal void CompleteCards() {
            while(instance.Score <= Game.CrupierLowerLimit && instance.Score <= Game.Goal) {
                instance.Cards.Add(new Game.Card());
            }
        }

    }

}