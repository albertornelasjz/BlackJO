﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackJO {

    /// <summary>
    /// Game class, this class is used to define the game steps
    /// </summary>
    public class Game {

        // Game constants
        internal const int InitialCardsQuantity = 2;
        internal const int Goal = 21;
        internal const int CrupierLowerLimit = 17;

        // Attributes
        public Crupier crupier;
        public List<Player> players;
        
        /// <summary>
        /// Constructor
        /// </summary>
        public Game() {                    
            players = new List<Player>();
            crupier = Crupier.Instance;            
        }
        
        /// <summary>
        /// Starts the game
        /// </summary>
        public void Start() {
            List<Player> winners;
            do {                
                ClearGame();
                AddPlayers(); 
                ServeInitialCards();
                ShowHand();
                ServeAdditionalCards();
                ShowHand();
                winners = ConcludeGame();
                ShowResults(winners);
            } while(Continue());
        }

        /// <summary>
        /// Show winners result
        /// </summary>
        /// <param name="winners"></param>
        private void ShowResults(List<Player> winners) {            
            UIHelper.AddLabel(String.Format("The winner(s) : {0}", winners.Count > 0 ? String.Join(", ", winners.Select(p => p.Name)) : "None"));
        }

        #region GAME FUNCTIONS
        /// <summary>
        /// Clears the game components
        /// </summary>
        private void ClearGame() {
            Console.Clear();
            players.Clear();
            crupier.Cards.Clear();
        }

        /// <summary>
        /// Add the players to the game
        /// </summary>
        private void AddPlayers() {
            string playerNames;
            string playerName;
            Player tempPlayer;
            do {
                UIHelper.AddLabel("Please add the player's name (Separated by comma) ...");
                playerNames = Console.ReadLine();
                if(string.IsNullOrEmpty(playerNames)) {
                    UIHelper.AddLabel("Please add the player's name (Separated by comma) ...");
                    playerNames = Console.ReadLine();
                    continue;
                }
                foreach(string name in playerNames.Split(',')) {
                    playerName = GetProperlyName(name);
                    tempPlayer = new Player(playerName);            
                    players.Add(tempPlayer);
                }
            } while(players.Count <= 0);
        }

        /// <summary>
        /// Asks and evaluates if the user wants to continue playing
        /// </summary>
        /// <returns>User response</returns>
        private bool Continue() {
            string response;
            UIHelper.AddLabel("Do you want to play again (y/n)?");
            response = Console.ReadKey(true).Key.ToString();
            // Any different response to "Yes" must be considered as negative response
            return response == "y" || response == "Y";
        }

        /// <summary>
        /// Concludes the game
        /// </summary>
        public List<Player> ConcludeGame() {
			int highScore;
			List<Player> winners;
			// Adds the crupier to be evaluated
			players.Add(crupier);
			// Perfect score evaluation
			winners = players.Where(p => p.Score.Equals(Goal)).ToList();
			if (winners.Count <= 0) {
				winners = players.Where(p => p.Score >= CrupierLowerLimit && p.Score <= Goal).OrderByDescending(o => o.Score).ToList();
				// By proximity
				if (winners.Count > 0) {
					highScore = winners.First().Score;
					winners = winners.Where(p => p.Score.Equals(highScore)).ToList();
				}
			}
			return winners.OrderBy(o => o.Name).ToList();         
        }

        /// <summary>
        /// Serving additional cards if the user requires it
        /// </summary>
        private void ServeAdditionalCards() {
            UIHelper.AddHeader("Additional C.");
            string response = "n";
            foreach(Player player in players) {
                do {
                    if(player.Score < Goal) {
                        // Ask for an additional card to the user
                        UIHelper.AddLabel(String.Format("{0}, Do you want another card (y/n)?", player.Name));
                        response = Console.ReadKey(true).Key.ToString();
                        if(response == "y" || response == "Y") {
                            player.Cards.Add(new Card());
                            player.ShowHand();
                        }
                    }
                } while((player.Score < Goal) & response != "n" & response != "N");
            }
            // Finally the crupier (Computer) completes it cards according the game's criterias
            crupier.CompleteCards();
            UIHelper.AddFooter();
        }

        /// <summary>
        /// Show the players' hand
        /// </summary>
        private void ShowHand() {
            UIHelper.AddHeader("Player's hand");
            foreach(Player player in players) {
                player.ShowHand();
            }
            crupier.ShowHand();
            UIHelper.AddFooter();
        }

        /// <summary>
        /// Gives the initial cards
        /// </summary>
        private void ServeInitialCards() {
            foreach(Player player in players) {
                AssignCards(player, InitialCardsQuantity);
            }
            AssignCards(Crupier.Instance, InitialCardsQuantity);
        }

        /// <summary>
        /// Assign cards to the user
        /// </summary>
        /// <param name="player">Player who will receive the card(s)</param>
        /// <param name="cardsQuantity">Cards quantity</param>
        private void AssignCards(Player player, int cardsQuantity) {
            for(int index = 0; index < cardsQuantity; index++) {
                player.Cards.Add(new Card());
            }
        }

        /// <summary>
        /// Corrects the player name (In case it is repetead or empty)
        /// </summary>        
        /// <param name="name">Original name</param>
        /// <returns>Fixed name</returns>
        private string GetProperlyName(string name) {
            int repeatedNamesCounter;
            name = string.IsNullOrEmpty(name) ? Player.DefaultPlayerName : name;
            repeatedNamesCounter = players.Where(n => n.Name.StartsWith(Player.DefaultPlayerName) || n.Name.Equals(name)).Count();
            return name + (repeatedNamesCounter > 0 ? " " + repeatedNamesCounter.ToString() : string.Empty);
        }
        #endregion

        #region NESTED CLASSES
        /// <summary>
        /// Card class
        /// </summary>
        public class Card {

            // Constants
            private const int MaxValue = 10;
            private const int MinValue = 1;

            // Attributes
            private static Random random;
            private int cardValue;

            /// <summary>
            /// Singleton implementation to ensure a only one instance of Random class.
            /// </summary>
            internal Random Random {
                get {
                    if(random == null) {
                        random = new Random();
                    }
                    return random;
                }
            }

            // Card value           
            public int Value {
                get { return cardValue; }
                set { cardValue = value < MinValue ? MinValue : (value > MaxValue ? MaxValue : value); }
            }

            /// <summary>
            /// Card constructor, assigns a card value between the game range
            /// </summary>
            public Card() {
                cardValue = Random.Next(MinValue, MaxValue);
            }

        } 
        #endregion

    }
    
}